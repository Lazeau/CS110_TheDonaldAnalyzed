import java.util.ArrayList;

public class Post {
	// Variables organized in order of column headings in .xlsx file
	private int score = 0;
	private int numComments = 0;
	private String selfText = "";
	private String thumbnail = "";
	private int numGilded = 0;
	private String author = "";
	private String title = "";
	private String date = "";
	private String subReddit = "";
	private String postUrl = "";
	private ArrayList<String> comments = new ArrayList<String>(); // Used ArrayList b/c posts have various #'s of comments
	
	// Constructor for all variables
	Post (int score, int numComments, String selfText, String thumbnail, int numGilded, String author,
			String title, String date, String subReddit, String postUrl, ArrayList<String> comments) {
		this.score = score;
		this.numComments = numComments;
		this.selfText = selfText;
		this.thumbnail = thumbnail;
		this.numGilded = numGilded;
		this.author = author;
		this.title = title;
		this.date = date;
		this.subReddit = subReddit;
		this.postUrl = postUrl;
		this.comments = comments;
		//System.out.println(this.comments);
	}
	
	// Organize the variables of this Post as a String
	public String toString() {
		String post = ("Subreddit: " + subReddit
				+ "\nScore: " + score + "\tNumber of Comments: " + numComments + "\tNum. Gilded: " + numGilded
				+ "\nTitle: " + title + "\tAuthor: " + author + "\tDate: " + date
				+ "\nSelf Text: " + selfText + "\tThumbnail URL: " + thumbnail
				+ "\nPost URL: " + postUrl);
		
		return post;
	}
	
	public int getScore() {
		return score;
	}
	
	public int getNumComments() {
		return numComments;
	}
	
	public String getselfText() {
		return selfText;
	}
	
	public String getThumbnail() {
		return thumbnail;
	}
	
	public int getNumGilded() {
		return numGilded;
	}
	
	public String getAuthor() {
		return author;
	}

	public String getTitle() {
		return title;
	}
	
	public String getDate() {
		return date;
	}
	
	public String getSubReddit() {
		return subReddit;
	}
	
	public String getPostUrl() {
		return postUrl;
	}
	
	public ArrayList<String> getComments() {
		return comments;
	}
}
