import java.util.Scanner;

/* Matthew Lazo
 * March 26, 2018
 * CS 110, 001
 * Dr. Norma S. Savage
 * 
 * Version 1.0
 * 
 * See README.txt for more information
 */

public class TheDonaldAnalyzed {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int input = 0;
		boolean doAnother = true;
		
		String database = "allRedditContent.csv";
		System.out.println(database);
		DataReader theDonald = new DataReader(database);
		
		System.out.println("RETRIEVING REDDIT POSTS FROM DATABASE...");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
		}
		theDonald.printPosts();
		
		while (doAnother) {
			// Menu
			System.out.println("\nDATA RETRIEVED. WHAT WOULD YOU LIKE TO KNOW ABOUT THE MAN, THE MYTH, THE DONALD?");
			System.out.println("[1] On this subreddit, is there a correlation between the number of comments on a post and its score?"
					+ "\n[2] What is the most popular post on /r/The_Donald?"
					+ "\n[3] Does /r/The_Donald really support the Don?"
					+ "\n[4] I know everything about the Donald. He's a great guy, he's YUUUUUUGE."
					+ "\nCHOOSE AN OPTION BY TYPING IN ITS NUMBER.");
			input = Integer.parseInt(in.next());
			
			// Handle user choice
			if (input == 1) {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
				}
				
				if (theDonald.correlation() == 1) {
					System.out.println("\nTHERE IS A CLEAR CORRELATION; THE MORE COMMENTS A POST HAS, THE HIGHER ITS SCORE IS LIKELY TO BE.");
				} else if (theDonald.correlation() == 2) {
					System.out.println("\nTHERE IS A CLEAR CORRELATION; THE MORE COMMENTS A POST HAS, THE LOWER ITS SCORE IS LIKELY TO BE.");
				} else if (theDonald.correlation() == 3) {
					System.out.println("\nTHERE IS NOT STRONG ENOUGH EVIDENCE TO SUPPORT THE EXISTENCE OF ANY CORRELATION BETWEEN SCORE AND NUMBER OF COMMENTS FOR A POSTS.");
				} else {
					System.out.println("\nOUR CORRELATION METHOD HAS BEEN HACKED BY THE RUSSIANS. DON'T WORRY, THE DON LET THEM DO IT, SO IT'S FINE."
							+ "\n(THERE WAS AN ERROR)");
				}
			} else if (input == 2) {
				Post mostPopular = theDonald.mostPopular();
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
				}
				
				System.out.println("\nTHIS IS THE MOST POPULAR POST ON THE SUBREDDIT:\n"
						+ mostPopular.toString());
			} else if (input == 3) {
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
				}
				
				if (theDonald.isPositive()) {
					System.out.println("OF COURSE. THIS SUBREDDIT IS THE BEST SUBREDDIT. ALL ITS PEOPLE ARE THE GREATEST AND THEY KNOW TO SUPPORT THE GREATEST.");
				} else {
					System.out.println("THESE MOOKS DON'T KNOW HOW GOOD THEY GOT IT. WE'LL LOCK 'EM OUT ONCE WE FINISH THE WALL.");
				}
			} else if (input == 4) {
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
				}
				
				System.out.println("GOOD TO SEE SUCH AN AVID SUPPORTER OF THE DONALD. HAVE A GREAT DAY.");
			} else {
				System.out.println("SOMETHING WENT WRONG! REBOOTING...");
			}
			
			// Ask if the user would like to restart the program
			System.out.println("WOULD YOU LIKE TO LEARN MORE ABOUT /R/THE_DONALD?"
					+ "\n[1] YES"
					+ "\n[2] NO");
			input = Integer.parseInt(in.next());
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			
			if (input == 1) {
				doAnother = true;
			} else if (input == 2) {
				System.out.println("ALRIGHT GET OUTTA HERE I GOT A COUNTRY TO RUN. HAVE A GREAT DAY.");
				doAnother = false;
			} else {
				System.out.println("SOMETHING WENT WRONG. LET'S RESTART.");
				doAnother = true;
			}
		}
		
	}
}