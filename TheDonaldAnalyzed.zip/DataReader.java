import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataReader {
	public String fileName = "";
	private String entry = "";
	private int score = 0;
	private int numComments = 0;
	private String selfText = "";
	private String thumbnail = "";
	private int numGilded = 0;
	private String author = "";
	private String title = "";
	private String date = "";
	private String subReddit = "";
	private String postUrl = "";
	private ArrayList<String> comments = new ArrayList<String>();
	public ArrayList<Post> posts = new ArrayList<Post>();
	
	public ArrayList<String> allComments = new ArrayList<String>();
	public ArrayList<Integer> allScores = new ArrayList<Integer>();
	public ArrayList<Integer> allNumComments = new ArrayList<Integer>();
	
	DataReader(String fileName) {
		this.fileName = fileName;
		readData(fileName);
		System.out.println("DATAREADER CONSTRUCTOR DONE");
	}
	
	public void readData(String fileName) {
		try {
			File fileIn = new File(fileName);
			FileInputStream fileData = new FileInputStream(fileIn);
			Scanner data = new Scanner(fileData);
			data.useDelimiter("\n");
			
			data.next();
			
			while (data.hasNext()) {
				comments.clear();
				int i = 0;
				
				Scanner dataLine = new Scanner(data.next());
				dataLine.useDelimiter(",");
												
				while (dataLine.hasNext()) {
					entry = dataLine.next();
					
					if (entry.length() > 0) {
						if (i < 10) {
						switch (i) {
							case 0:
								score = Integer.parseInt(entry);
								allScores.add(Integer.parseInt(entry));
								break;
								
								//numComments unknown, no case 1
								
							case 2:
								selfText = entry;
								break;
								
							case 3:
								thumbnail = entry;
								break;
								
							case 4:
								numGilded = Integer.parseInt(entry);
								break;
								
							case 5:
								author = entry;
								break;
								
							case 6:
								title = entry;
								break;
								
							case 7:
								date = entry;
								break;
								
							case 8:
								subReddit = entry;
								break;
								
							case 9:
								postUrl = entry;
								break;
							}
						} else {
							comments.add(entry);
							allComments.add(entry);
						}
						
					}
					
					i++;
				}
				
				numComments = comments.size();
				allNumComments.add(numComments);
				posts.add(new Post(score, numComments, selfText, thumbnail, numGilded, author, title, date, subReddit, postUrl, comments));
								
				dataLine.close();
			}
			data.close();
		} catch (Exception e) {
			System.out.println("ERROR READING DATA FILE");
		}
	}
	
	public void printPosts() {
		for (int i = 0; i < posts.size(); i++) {
			System.out.println("\n");
			System.out.println(posts.get(i).toString());
		}
	}
	
	// Returns a boolean value, true if there is more positivty than negativity, false otherwise
	public boolean isPositive() {
		int positive = 0;
		int negative = 0;
		
		for (int i = 0; i < allComments.size(); i++) {
			if ((allComments.get(i).contains("good") || allComments.get(i).contains("great") || allComments.get(i).contains("awesome") || allComments.get(i).contains("nice")
					|| allComments.get(i).contains("cool") || allComments.get(i).contains("like") || allComments.get(i).contains("love") || allComments.get(i).contains("positive"))
					&& (allComments.get(i).contains("trump") || allComments.get(i).contains("pence"))) {
				positive++;
			} else if ((allComments.get(i).contains("bad") || allComments.get(i).contains("terrible") || allComments.get(i).contains("horrible") || allComments.get(i).contains("disgusting")
					|| allComments.get(i).contains("horrid") || allComments.get(i).contains("terrifying") || allComments.get(i).contains("worse") || allComments.get(i).contains("worst")
					|| allComments.get(i).contains("downturn"))
					&& (allComments.get(i).contains("trump") || allComments.get(i).contains("pence"))) {
				negative++;
			}
		}
		
		if (positive > negative) {
			return true;
		} else {
			return false;
		}
	}
	
	// Returns the Post object with the highest score out of all the Post objects in the data
	public Post mostPopular() {
		int maxScore = Integer.MIN_VALUE;
		int index = 0;
		
		for (int i = 1; i < allScores.size(); i++) {
			if (allScores.get(i) > maxScore) {
				maxScore = allScores.get(i);
				index = i;
			}
		}
		
		return posts.get(index);
	}
	
	//
	public int correlation() {
		int i1 = 0;
		int i2 = (posts.size()/4) - 1;
		int i3 = (posts.size()/2) - 1;
		int i4 = ((3 * posts.size())/4) - 1;
		int i5 = posts.size() - 1;
		
		int m1 = slope(posts.get(i1).getScore(), posts.get(i2).getScore(), posts.get(i1).getNumComments(), posts.get(i2).getNumComments());
		int m2 = slope(posts.get(i2).getScore(), posts.get(i3).getScore(), posts.get(i2).getNumComments(), posts.get(i3).getNumComments());
		int m3 = slope(posts.get(i3).getScore(), posts.get(i4).getScore(), posts.get(i3).getNumComments(), posts.get(i4).getNumComments());
		int m4 = slope(posts.get(i4).getScore(), posts.get(i5).getScore(), posts.get(i4).getNumComments(), posts.get(i5).getNumComments());
		
		if (m1 < m2 && m2 < m3 && m3 < m4) {
			return 1;
		} else if (m4 < m3 && m3 < m2 && m2 < m1) {
			return 2;
		} else {
			return 3;
		}
	}
	
	public int slope(int x1, int x2, int y1, int y2) {
		return (y2 - y1)/(x2 - x1);
	}
	
}
